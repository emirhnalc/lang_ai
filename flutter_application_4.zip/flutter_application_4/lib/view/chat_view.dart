import 'package:flutter/material.dart';
import 'package:flutter_application_4/controller/sentences_controller.dart';
import 'package:flutter_application_4/data/repositories/sentences_repositor_iml.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key, required this.title});

  final String title;

  @override
  State<ChatPage> createState() => ChatPageState();
}

class ChatPageState extends State<ChatPage> {
  final SentencesController sentencesController = SentencesController();
  final ScrollController scrollController = ScrollController();
  String sentences = 'The answer will be here...';
  final List<String> messages = [];
  final TextEditingController messageController = TextEditingController();
  PoemRepositoryImpl poemRepositoryImpl = PoemRepositoryImpl();

  bool isLoading = false;
  void sendMessage(String message) async {
    if (messageController.text.isNotEmpty) {
      setState(() {
        messages.add(messageController.text);
        isLoading = true;
        messageController.clear();
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeOut,
        );
      });

      var sentencesData = await sentencesController.getPoem(message, context);

      setState(() {
        sentences = sentencesData;
        messages.add(sentences);
        isLoading = false;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeOut,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'LangAI',
          style: GoogleFonts.getFont('Noto Sans Elymaic',
              textStyle: TextStyle(color: Colors.black, fontSize: 24)),
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: <Widget>[
          Expanded(child: buildMessageList()),
          buildMessageInputField(),
        ],
      ),
    );
  }

  ListView buildMessageList() {
    return ListView.builder(
      controller: scrollController,
      itemCount: isLoading ? messages.length + 1 : messages.length,
      itemBuilder: (context, index) {
        if (isLoading && index == messages.length) {
          return Align(
            alignment: Alignment.centerLeft,
            child: Lottie.asset('assets/images/animation.json',
                width: 250, height: 250),
          );
        } else {
          return Align(
            alignment:
                index % 2 == 0 ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              padding: const EdgeInsets.all(10.0),
              margin: const EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: index % 2 == 0
                    ? Colors.orange[100]
                    : Color(0xFFCAD6FF),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Text(
                messages[index],
                style: const TextStyle(fontSize: 20),
              ),
            ),
          );
        }
      },
    );
  }

  Widget buildMessageInputField() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              controller: messageController,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                labelText: 'Please enter a word to get sentences...',
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.send),
            onPressed: () {
              sendMessage(messageController.text);
            },
          ),
        ],
      ),
    );
  }
}
