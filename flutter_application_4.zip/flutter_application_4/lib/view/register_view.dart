import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_4/view/login_view.dart';
import 'package:flutter_application_4/viewmodel/register_view_model.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RegisterView extends StatefulWidget {
  const RegisterView({super.key});

  @override
  State<RegisterView> createState() => _RegisterViewState();
}

class _RegisterViewState extends State<RegisterView> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  late FocusNode myFocusNode1;
  late FocusNode myFocusNode2;
  bool isPasswordVisible = true;
  @override
  void initState() {
    super.initState();
    myFocusNode1 = FocusNode();
    myFocusNode2 = FocusNode();
  }

  @override
  void dispose() {
    myFocusNode1.dispose();
    myFocusNode2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/images/objects.png"), // buraya resminizin yolunu yazın
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(
              height: 140,
            ),
            _buildHeader(),
            const SizedBox(
              height: 60,
            ),
            _buildEmail(),
            const SizedBox(
              height: 20,
            ),
            _buildPassword(),
            const SizedBox(
              height: 20,
            ),
            _buildConfirmPassword(),
            const SizedBox(
              height: 50,
            ),
            _buildLoginButton(),
            const SizedBox(
              height: 20,
            ),
            _buildCreateAccountButton(),
            const SizedBox(
              height: 50,
            ),
            _buildWithLoginSocialMedia(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Center(
          child: Text(
            'Create Account',
            style: GoogleFonts.poppins(
              textStyle: Theme.of(context).textTheme.headlineLarge,
              fontWeight: FontWeight.bold,
              fontSize: 35,
              color: const Color(0xFF1F41BB),
              shadows: [
                const Shadow(
                  offset: Offset(1.3, 1.2),
                  blurRadius: 4.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmail() {
    return Padding(
      padding: const EdgeInsets.only(left: 28, right: 28),
      child: TextField(
        controller: emailController,
        keyboardType: TextInputType.emailAddress,
        autofocus: true,
        onSubmitted: (term) {
          FocusScope.of(context).requestFocus(myFocusNode1);
        },
        decoration: InputDecoration(
          fillColor: const Color(0xFFF1F4FF),
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Color(0xFFFF0000),
              style: BorderStyle.solid,
              width: 5,
            ),
          ),
          labelText: 'Email',
        ),
      ),
    );
  }

  Widget _buildPassword() {
    return Padding(
      padding: const EdgeInsets.only(left: 28, right: 28),
      child: TextField(
        controller: passwordController,
        focusNode: myFocusNode1,
        onSubmitted: (term) {
          FocusScope.of(context).requestFocus(myFocusNode2);
        },
        cursorColor: const Color.fromARGB(255, 29, 41, 86),
        keyboardType: TextInputType.multiline,
        obscureText: isPasswordVisible,
        decoration: InputDecoration(
          suffixIcon: IconButton(
              icon: const Icon(Icons.visibility),
              onPressed: () {
                setState(() {
                  isPasswordVisible = !isPasswordVisible;
                });
              }),
          fillColor: const Color(0xFFF1F4FF),
          filled: true,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: Color(0xFF1F41BB),
                width: 5,
              )),
          labelText: 'Password',
        ),
      ),
    );
  }

  Widget _buildConfirmPassword() {
    return Padding(
      padding: const EdgeInsets.only(left: 28, right: 28),
      child: TextField(
        controller: confirmPasswordController,
        focusNode: myFocusNode2,
        cursorColor: const Color.fromARGB(255, 29, 41, 86),
        obscureText: isPasswordVisible,
        decoration: InputDecoration(
          suffixIcon: IconButton(
              icon: const Icon(Icons.visibility),
              onPressed: () {
                setState(() {
                  isPasswordVisible = !isPasswordVisible;
                  print('Password is visible');
                });
              }),
          fillColor: const Color(0xFFF1F4FF),
          filled: true,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: Color(0xFF1F41BB),
                width: 5,
              )),
          labelText: 'Confirm Password',
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return Consumer<RegisterViewModel>(
      builder: (context, value, child) {
        return InkWell(
          onTap: () async {
            if (passwordController.text == confirmPasswordController.text) {
              value.registerUser(emailController.text, passwordController.text);
              Future.delayed(const Duration(seconds: 2), () async {
                Navigator.pushNamed(context, '/');
              });
            } else {
              print('Passwords do not match');
            }
          },
          child: AnimatedContainer(
            width: 357,
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            decoration: ShapeDecoration(
              color: const Color(0xFF1F41BB),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              shadows: const [
                BoxShadow(
                  color: Color(0xFFCAD6FF),
                  blurRadius: 20,
                  offset: Offset(0, 10),
                  spreadRadius: 0,
                )
              ],
            ),
            duration: const Duration(seconds: 2),
            curve: Curves.bounceInOut,
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Sign in',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCreateAccountButton() {
    return TextButton(
      onPressed: () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => LoginView(),
            ));
      },
      child: Text(
        textAlign: TextAlign.right,
        'Already have an account',
        style: GoogleFonts.poppins(
          fontWeight: FontWeight.w600,
          fontSize: 14,
          color: const Color(0xFF494949),
        ),
      ),
    );
  }

  Widget _buildWithLoginSocialMedia() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          textAlign: TextAlign.right,
          'Or continue with ',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            fontSize: 14,
            color: const Color(0xFF1F41BB),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildSocialMediaButton('assets/images/googlee.png'),
            const SizedBox(
              width: 10,
            ),
            _buildSocialMediaButton('assets/images/facebook.png'),
            const SizedBox(
              width: 10,
            ),
            _buildSocialMediaButton('assets/images/apple.png'),
          ],
        )
      ],
    );
  }

  Widget _buildSocialMediaButton(String imagePath) {
    return Container(
      width: 60,
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: ShapeDecoration(
        color: const Color(0xFFEBEBEB),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Image.asset(
        imagePath,
        fit: BoxFit.cover,
      ),
    );
  }
}
