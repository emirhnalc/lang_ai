import 'package:flutter/material.dart';
import 'package:flutter_application_4/viewmodel/language_model.dart';
import 'package:provider/provider.dart';

class LanguageSelectView extends StatefulWidget {
  const LanguageSelectView({super.key});

  @override
  State<LanguageSelectView> createState() => _LanguageSelectViewState();
}

class _LanguageSelectViewState extends State<LanguageSelectView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: const Text(
          "Language Select",
          style: TextStyle(
            color: Colors.black,
            fontSize: 24,
          ),
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Consumer<LanguageModel>(
        builder: (context, languageModel, child) {
          return Column(
            children: [
              Image.asset('assets/images/ai.jpg'),
              const SizedBox(height: 20),
              const Text(
                "Select 1. Language",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              _buildSelectLanguage(languageModel),
              const SizedBox(height: 20),
              const Text(
                "Select 2. Language",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              _buildSecondSelectLanguage(languageModel),
              const SizedBox(height: 30),
              _buildSubmitButton(languageModel),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSelectLanguage(LanguageModel languageModel) {
    return Container(
      width: 150,
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: ShapeDecoration(
        color: const Color.fromARGB(255, 122, 143, 221),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        shadows: const [
          BoxShadow(
            color: Color(0xFFCAD6FF),
            blurRadius: 20,
            offset: Offset(0, 10),
            spreadRadius: 0,
          )
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton(
          dropdownColor: const Color.fromARGB(255, 122, 143, 221),
          value: languageModel.selectedLanguage,
          items: languageModel.languages.map((String language) {
            return DropdownMenuItem(
              value: language,
              child: Text(
                language,
                style: const TextStyle(color: Colors.white),
              ),
            );
          }).toList(),
          onChanged: (dynamic newValue) {
            languageModel.setSelectedLanguage(newValue);
            print(languageModel
                .selectedSecondLanguage); // print selected language
          },
        ),
      ),
    );
  }

  Widget _buildSecondSelectLanguage(LanguageModel languageModel) {
    return Container(
      width: 150,
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: ShapeDecoration(
        color: const Color.fromARGB(255, 122, 143, 221),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        shadows: const [
          BoxShadow(
            color: Color(0xFFCAD6FF),
            blurRadius: 20,
            offset: Offset(0, 10),
            spreadRadius: 0,
          )
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton(
          dropdownColor: const Color.fromARGB(255, 122, 143, 221),
          value: languageModel.selectedSecondLanguage,
          items: languageModel.secondLanguages.map((String language) {
            return DropdownMenuItem(
              value: language,
              child: Text(
                textAlign: TextAlign.center,
                language,
                style: const TextStyle(color: Colors.white),
              ),
            );
          }).toList(),
          onChanged: (dynamic newValue) {
            languageModel.setSecondSelectedLanguage(newValue);
            print(languageModel.selectedLanguage);
          },
        ),
      ),
    );
  }

  Widget _buildSubmitButton(LanguageModel languageModel) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, "/chatPage");
      },
      child: AnimatedContainer(
        width: 200,
        height: 60,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        decoration: ShapeDecoration(
          color: const Color(0xFF1F41BB),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          shadows: const [
            BoxShadow(
              color: Color(0xFFCAD6FF),
              blurRadius: 20,
              offset: Offset(0, 10),
              spreadRadius: 0,
            )
          ],
        ),
        duration: const Duration(seconds: 2),
        curve: Curves.bounceInOut,
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Continue',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 0,
              ),
            ),
            SizedBox(
              width: 10,
              height: 0,
            ),
            Icon(
              Icons.arrow_forward,
              color: Colors.white,
            ),
          ],
        ),
      ),
    );
  }
}
