import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_4/view/language_select_view.dart';
import 'package:flutter_application_4/view/register_view.dart';
import 'package:flutter_application_4/viewmodel/register_view_model.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:toastification/toastification.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  late FocusNode myFocusNode;
  bool isPasswordVisible = true;
  @override
  void initState() {
    super.initState();
    myFocusNode = FocusNode();
  }

  @override
  void dispose() {
    myFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/images/objects.png"), // buraya resminizin yolunu yazın
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(
              height: 100,
            ),
            _buildApplicationName(),
            const SizedBox(
              height: 20,
            ),
            _buildApplicationLogo(),
            const SizedBox(
              height: 60,
            ),
            _buildEmail(),
            const SizedBox(
              height: 20,
            ),
            _buildPassword(),
            const SizedBox(
              height: 20,
            ),
            Align(
              alignment: Alignment.centerRight,
              child: _buildTextButton(),
            ),
            const SizedBox(
              height: 20,
            ),
            _buildLoginButton(),
            const SizedBox(
              height: 20,
            ),
            _buildCreateAccountButton(),
            const SizedBox(
              height: 50,
            ),
            _buildWithLoginSocialMedia(),
          ],
        ),
      ),
    );
  }

  Widget _buildApplicationName() {
    return Text(
      'LangAI',
      style: GoogleFonts.getFont(
        'Noto Sans Elymaic',
        fontWeight: FontWeight.bold,
        fontSize: 40,
        color: const Color(0xFF1F41BB),
        shadows: [
          const Shadow(
            offset: Offset(1.3, 1.2),
            blurRadius: 4.0,
            color: Color.fromARGB(255, 0, 0, 0),
          ),
        ],
      ),
    );
  }

  Widget _buildApplicationLogo() {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        image: const DecorationImage(
          image: AssetImage('assets/images/icon.png'),
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Center(
          child: Text(
            'Login Here',
            style: GoogleFonts.poppins(
              textStyle: Theme.of(context).textTheme.headlineLarge,
              fontWeight: FontWeight.bold,
              fontSize: 35,
              color: const Color(0xFF1F41BB),
              shadows: [
                const Shadow(
                  offset: Offset(1.3, 1.2),
                  blurRadius: 4.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmail() {
    return Padding(
      padding: const EdgeInsets.only(left: 28, right: 28),
      child: TextField(
        controller: emailController,
        autofocus: true,
        onSubmitted: (term) {
          FocusScope.of(context).requestFocus(myFocusNode);
        },
        decoration: InputDecoration(
          fillColor: const Color(0xFFF1F4FF),
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Color(0xFFFF0000),
              style: BorderStyle.solid,
              width: 5,
            ),
          ),
          labelText: 'Email',
        ),
      ),
    );
  }

  Widget _buildPassword() {
    return Padding(
      padding: const EdgeInsets.only(left: 28, right: 28),
      child: TextField(
        controller: passwordController,
        focusNode: myFocusNode,
        cursorColor: const Color.fromARGB(255, 29, 41, 86),
        obscureText: isPasswordVisible,
        decoration: InputDecoration(
          suffixIcon: IconButton(
              icon: const Icon(Icons.visibility),
              onPressed: () {
                setState(() {
                  isPasswordVisible = !isPasswordVisible;
                  print('Password is visible');
                });
              }),
          fillColor: const Color(0xFFF1F4FF),
          filled: true,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: Color(0xFF1F41BB),
                width: 5,
              )),
          labelText: 'Password',
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return Consumer<RegisterViewModel>(
      builder: (context, value, child) {
        return InkWell(
          onTap: () {
            FocusScope.of(context).unfocus();
            if (emailController.text.isNotEmpty &&
                passwordController.text.isNotEmpty) {
              value
                  .checkUserCredentials(
                      emailController.text, passwordController.text)
                  .then((value) {
                if (value) {
                  toastification.show(
                    context: context,
                    type: ToastificationType.success,
                    backgroundColor: Colors.green,
                    showProgressBar: false,
                    icon: const Icon(
                      Icons.check,
                      color: Colors.white,
                    ),
                    title: const Text(
                      'Login successful',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                    autoCloseDuration: const Duration(seconds: 2),
                  );
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LanguageSelectView(),
                    ),
                  );
                } else {
                  toastification.show(
                    context: context,
                    type: ToastificationType.error,
                    style: ToastificationStyle.flat,
                    direction: TextDirection.ltr,
                    alignment: Alignment.topCenter,
                    showProgressBar: false,
                    icon: const Icon(
                      Icons.highlight_off,
                      color: Colors.white,
                    ),
                    backgroundColor: Colors.red,
                    title: const Text(
                      'Email or password is incorrect',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                    autoCloseDuration: const Duration(seconds: 3),
                  );
                }
              });
            } else {
              toastification.show(
                context: context,
                type: ToastificationType.error,
                style: ToastificationStyle.flat,
                direction: TextDirection.ltr,
                alignment: Alignment.topCenter,
                showProgressBar: false,
                icon: const Icon(
                  Icons.warning,
                  color: Colors.white,
                ),
                backgroundColor: Colors.orange,
                title: const Text(
                  'Email or password cannot be empty',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
                autoCloseDuration: const Duration(seconds: 5),
              );
            }
          },
          child: AnimatedContainer(
            width: 357,
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            decoration: ShapeDecoration(
              color: const Color(0xFF1F41BB),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              shadows: const [
                BoxShadow(
                  color: Color(0xFFCAD6FF),
                  blurRadius: 20,
                  offset: Offset(0, 10),
                  spreadRadius: 0,
                )
              ],
            ),
            duration: const Duration(seconds: 2),
            curve: Curves.bounceInOut,
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Sign in',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTextButton() {
    return TextButton(
      onPressed: () {},
      child: Text(
        textAlign: TextAlign.right,
        'Forgot your password?',
        style: GoogleFonts.poppins(
          fontWeight: FontWeight.w600,
          fontSize: 14,
          color: const Color(0xFF1F41BB),
        ),
      ),
    );
  }

  Widget _buildCreateAccountButton() {
    return TextButton(
      onPressed: () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => RegisterView(),
            ));
      },
      child: Text(
        textAlign: TextAlign.right,
        'Create new account',
        style: GoogleFonts.poppins(
          fontWeight: FontWeight.w600,
          fontSize: 14,
          color: const Color(0xFF494949),
        ),
      ),
    );
  }

  Widget _buildWithLoginSocialMedia() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          textAlign: TextAlign.right,
          'Or continue with ',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            fontSize: 14,
            color: const Color(0xFF1F41BB),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildSocialMediaButton('assets/images/googlee.png'),
            const SizedBox(
              width: 10,
            ),
            _buildSocialMediaButton('assets/images/facebook.png'),
            const SizedBox(
              width: 10,
            ),
            _buildSocialMediaButton('assets/images/apple.png'),
          ],
        )
      ],
    );
  }

  Widget _buildSocialMediaButton(String imagePath) {
    return Container(
      width: 60,
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: ShapeDecoration(
        color: const Color(0xFFEBEBEB),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Image.asset(
        imagePath,
        fit: BoxFit.cover,
      ),
    );
  }
}
