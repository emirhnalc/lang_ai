import 'package:flutter/material.dart';

import 'package:flutter_application_4/view/chat_view.dart';
import 'package:flutter_application_4/view/language_select_view.dart';
import 'package:flutter_application_4/view/login_view.dart';
import 'package:flutter_application_4/view/register_view.dart';
import 'package:flutter_application_4/viewmodel/language_model.dart';
import 'package:flutter_application_4/viewmodel/register_view_model.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => LanguageModel()),
        ChangeNotifierProvider(
          create: (context) => RegisterViewModel(),
        )
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Sentences Creator',
        theme: ThemeData(useMaterial3: true, fontFamily: "FiraCode"),
        initialRoute: "/",
        routes: {
          "/": (context) => const LoginView(),
          "/register": (context) => const RegisterView(),
          "/languageSelect": (context) => const LanguageSelectView(),
          "/chatPage": (context) =>
              const ChatPage(title: 'Sentences Creator For Words'),
        },
      ),
    );
  }
}
