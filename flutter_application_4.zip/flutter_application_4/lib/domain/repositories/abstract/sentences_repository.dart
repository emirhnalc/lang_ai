import 'package:flutter/src/widgets/framework.dart';

abstract class PoemRepository {
  Future<String> getPoems(String productName, BuildContext context);
}
