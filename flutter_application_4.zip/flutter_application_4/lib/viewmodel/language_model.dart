import 'package:flutter/material.dart';

class LanguageModel with ChangeNotifier {
  final List<String> _secondLanguages = [
    'İnglizce',
    'Türkçe',
    'Almanca',
    'İtalyanca',
    'Fransızca',
    'İspanyolca'
  ];
  final List<String> _firtsLanguages = [
    'İnglizce',
    'Türkçe',
    'Almanca',
    'İtalyanca',
    'Fransızca',
    'İspanyolca'
  ];
  String _selectedLanguage = 'İnglizce';

  String get selectedLanguage => _selectedLanguage;
  List<String> get languages => _firtsLanguages;
  
  void setSelectedLanguage(String newLanguage) {
    _selectedLanguage = newLanguage;
    notifyListeners();
  }

  String _selectedSecondLanguage = 'Türkçe';

  String get selectedSecondLanguage => _selectedSecondLanguage;
  List<String> get secondLanguages => _secondLanguages;

  void setSecondSelectedLanguage(String newLanguage) {
    _selectedSecondLanguage = newLanguage;
    notifyListeners();
  }
}
