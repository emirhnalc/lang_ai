import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RegisterViewModel with ChangeNotifier {
  Future<void> _saveUserData(String username, String password) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var users = prefs.getStringList('users') ?? [];
    var user = '$username:$password';
    users.add(user);
    await prefs.setStringList('users', users);
  }

  void registerUser(String username, String password) {
    _saveUserData(username, password);
  }

  Future<String?> getUserPassword(String username) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var users = prefs.getStringList('users') ?? [];
    var user = users.firstWhere((user) => user.startsWith('$username:'),
        orElse: () => '');
    return user?.split(':')[1];
  }

  Future<bool> checkUserCredentials(String username, String password) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var users = prefs.getStringList('users') ?? [];

    for (var user in users) {
      var userCredentials = user.split(':');
      if (userCredentials[0] == username && userCredentials[1] == password) {
        return true;
      }
    }
    return false;
  }
}
